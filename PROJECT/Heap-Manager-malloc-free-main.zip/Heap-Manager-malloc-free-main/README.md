# Heap-Manager-malloc-free-
This is a part of my Data Structures and Algorithm (DSA) course Mini-Project.

This is a implementation of Malloc, Calloc, Realloc and Free functions used in C. I have used the reference of "Tcmalloc" which is a heap manager by Google for the idea of Size-classes.
### NOTE : This is only for Linux Operating systems like Ubuntu. It does not work for Windows Applications.


